//사용되는 헤더
#include <sys/types.h>      //socket, 정수형 확장 자료형, pthread 관련 자료형을 포함하는 헤더
#include <sys/socket.h>     //socket관련 함수, 자료형들을 사용하기 위한 헤더
#include <netinet/in.h>     //network관련 함수, 자료형을 사용하기 위한 헤더
#include <netdb.h>          //network관련 함수, 자료형을 사용하기 위한 헤더
#include <pthread.h>        //POSIX 쓰레드 관련 함수
#include <stdio.h>          //표준입출력
#include <string.h>         //문자열 처리
#include <sys/ipc.h>        //msgq, semaphore등 ipc를 사용하기 위한 헤더
#include <sys/msg.h>        //msg queue 사용을 위한 확장 자료형을 포함하는 헤더
#include <stdlib.h>
#include <unistd.h>           //for the close function.

void *serverthread(void *parm); /* thread function prototype    */
void *evalthread();             /* thread function prototype    */

pthread_mutex_t mut;

#define PROTOPORT 5193 /* default protocol port number */
#define QLEN 6         /* size of request queue        */
#define MAXTEXT 100
int visits = 0; /* counts client connections     */

int evalgame(char, char, char);
int main(int argc, char *argv[])
{
    struct hostent *ptrh;   /* pointer to a host table entry */
    struct protoent *ptrp;  /* pointer to a protocol table entry */
    struct sockaddr_in sad; /* structure to hold server's address */
    struct sockaddr_in cad; /* structure to hold client's address */
    int sd, sd2,sd3;            /* socket descriptors */
    int port;               /* protocol port number */
    int alen;               /* length of address */
    pthread_t tid;          /* variable to hold thread ID */
    pthread_t eid;          /* variable to hold thread ID */
    pthread_mutex_init(&mut, NULL);
    memset((char *)&sad, 0, sizeof(sad)); /* clear sockaddr structure   */
    sad.sin_family = AF_INET;             /* set family to Internet     */
    sad.sin_addr.s_addr = INADDR_ANY;     /* set the local IP address */

    /* Check  command-line argument for protocol port and extract      */
    /* port number if one is specfied.  Otherwise, use the default     */
    /* port value given by constant PROTOPORT                          */

    if (argc > 1)
    {                         /* if argument specified     */
        port = atoi(argv[1]); /* convert argument to binary*/
    }
    else
    {
        port = PROTOPORT; /* use default port number   */
    }
    if (port > 0) {/* test for illegal value    */
        sad.sin_port = htons((u_short)port);
    }
    else
    { /* print error message and exit */
        fprintf(stderr, "bad port number %s/n", argv[1]);
        exit(1);
    }

    /* Map TCP transport protocol name to protocol number */

    if (((ptrp = getprotobyname("tcp"))) == 0)
    {
        fprintf(stderr, "cannot map \"tcp\" to protocol number");
        exit(1);
    }
    /* Create a socket */
    sd = socket(PF_INET, SOCK_STREAM, ptrp->p_proto);

    int option = 1; // to set the option of socket >> protect the bind error
    setsockopt(sd, SOL_SOCKET, SO_REUSEADDR, &option, sizeof(option));
	

    if (sd < 0)
    {
        fprintf(stderr, "socket creation failed\n");
        exit(1);
    }
    /* Bind a local address to the socket */
    if (bind(sd, (struct sockaddr *)&sad, sizeof(sad)) < 0)
    {
        fprintf(stderr, "bind failed\n");
        exit(1);
    }

    /* Specify a size of request queue */
    if (listen(sd, QLEN) < 0)
    {
        fprintf(stderr, "listen failed\n");
        exit(1);
    }

    alen = sizeof(cad);
    //error check end.
    pthread_create(&eid, NULL, evalthread, NULL); // eval thread run first

    /* Main server loop - accept and handle requests */

    fprintf(stderr, "Server up and running.\n");

    while (1)
    {
        printf("SERVER: Waiting for contact ...\n");

        if ((sd2 = accept(sd, (struct sockaddr *)&cad, &alen)) < 0)
        {
            fprintf(stderr, "accept failed\n");
            exit(1);
        }
        pthread_create(&tid, NULL, serverthread, (void *)&sd2);
    } /* end of while */
    close(sd);
    return 0;
}

void *serverthread(void *parm)
{
    int tsd;
    char buf[100]; /* buffer for string the server sends */
    int n;
    pthread_t id;
    
    int mqid;
    // struct gameid my_data;

    tsd = *(int*)parm;
    pthread_mutex_lock(&mut);
    ++visits;
    printf(" %d clients connected...\n", visits);
    pthread_mutex_unlock(&mut);

    if (visits == 1)
    {
        if ((mqid = msgget((key_t)1111, 0666 | IPC_CREAT)) == -1)
        {
            printf("1111 msgget failed \n");
            pthread_exit(0);
        }
    }
    else if (visits == 2)
    {
        if ((mqid = msgget((key_t)2222, 0666 | IPC_CREAT)) == -1)
        {
            printf("2222 msgget failed \n");
            pthread_exit(0);
        }
    }
    else if (visits == 3)
    {
        if ((mqid = msgget((key_t)3333, 0666 | IPC_CREAT)) == -1)
        {
            printf("3333 msgget failed \n");
            pthread_exit(0);
        }
    }
    id = pthread_self();
    sprintf(buf, "Your PID in Server is %lu .. \n", id);
    printf("SERVER thread: %s .. waiting..\n", buf);
    send(tsd, buf, strlen(buf), 0);

    while(visits!=3){
        sleep(1);
    }
    if(visits ==3){
        printf("Start Game!\n");
    }

    while (1)
    {
        n = recv(tsd, buf, sizeof(buf), 0);
        buf[n] = '\0';
        printf("Server thread : you type ->  %s\n", buf);
        switch (buf[0])
        {
        case 'W':
        case 'M':
        case 'V':
            msgsnd(mqid, buf, MAXTEXT, 0);
            printf("Server thread : send it to evalthread \n");
            break;
        case 'Q':
            sprintf(buf, " Finish game .. \n");
            send(tsd, buf, strlen(buf), 0);
            printf("SERVER thread: %lu .. exit()..", id);
            if (msgctl(mqid, IPC_RMID, NULL) == -1)
            {
                printf("msgctl failed \n");
            }
            close(tsd);
            pthread_exit(0);
            break;
        default:
            sprintf(buf, " invalid  input.. try again.. \n");
            send(tsd, buf, strlen(buf), 0);
            break;
        }
        if (msgrcv(mqid, buf, MAXTEXT, 0, MSG_NOERROR) == -1)
        {
            printf("mq_b msgrcv failed with error \n");
            pthread_exit(0);
        }

        printf("SERVER : thread(%lu) is  %s \n", id, buf);
        send(tsd, buf, strlen(buf), 0);
        buf[0] = '\0'; // clear buff string
    }                  /** end of while */
}

void *evalthread()
{
    int t;
    int mqid_a;
    int mqid_b;
    int mqid_c;
    
    char bufA[10], bufB[10],bufC[10];
    key_t key_qa = 1111, key_qb = 2222, key_qc =3333;

    printf("SERVER: eval thread running .\n");
    if ((mqid_a = msgget(key_qa, IPC_CREAT | 0666)) == -1)
    {
        printf("key_qa msgget failed \n");
        pthread_exit(0);
    }
    if ((mqid_b = msgget(key_qb, IPC_CREAT | 0666)) == -1)
    {
        printf("key_qb msgget failed \n");
        pthread_exit(0);
    }
    if ((mqid_c = msgget(key_qc, IPC_CREAT | 0666)) == -1)
    {
        printf("key_qc msgget failed \n");
        pthread_exit(0);
    }
    printf(" three message queues connected\n");
    
    while (1)
    {
        bufA[0] = '\0';
        bufB[0] = '\0';
        bufC[0] = '\0';
        if (msgrcv(mqid_a, bufA, MAXTEXT, 0, MSG_NOERROR) == -1)
        {
            printf("mg_a msgrcv failed with error \n");
            pthread_exit(0);
        }
        printf(" I get one and waiting : A-> %s \n", bufA);

        if (msgrcv(mqid_b, bufB, MAXTEXT, 0, MSG_NOERROR) == -1)
        {
            printf("mq_b msgrcv failed with error \n");
            pthread_exit(0);
        }
        printf(" I get two and eval it : B-> %s \n", bufB);

        if (msgrcv(mqid_c, bufC, MAXTEXT, 0, MSG_NOERROR) == -1)
        {
            printf("mq_c msgrcv failed with error \n");
            pthread_exit(0);
        }
        printf(" I get three and eval it : C-> %s \n", bufC);
        if (bufA[0] != '\0' && bufB[0] != '\0' && bufC[0]!='\0')
        {   
            t = 0;
            t = evalgame(bufA[0], bufB[0],bufC[0]);
            printf("SERVER evalgame: eval -> %d\n", t);

            switch (t)
            {
            case 0: //draw
                strcpy(bufA, "retry");
                strcpy(bufB, "retry");
                strcpy(bufC, "retry");
                break;
            case 1: //A win
                strcpy(bufA, "win");
                strcpy(bufB, "lose");
                strcpy(bufC, "lose");
                break;
            case 2: //B win
                strcpy(bufA, "lose");
                strcpy(bufB, "win");
                strcpy(bufC, "lose");
                break;
            case 3: //C win
                strcpy(bufA, "lose");
                strcpy(bufB, "lose");
                strcpy(bufC, "win");
                break;
            case 4: //A,B win
                strcpy(bufA, "win");
                strcpy(bufB, "win");
                strcpy(bufC, "lose");
                break;
            case 5: //A,C win
                strcpy(bufA, "win");
                strcpy(bufB, "lose");
                strcpy(bufC, "win");
                break;
            case 6: //B, C 
                strcpy(bufA, "lose");
                strcpy(bufB, "win");
                strcpy(bufC, "win");
                break;
            } /* end of switch */
            if(msgsnd(mqid_a, bufA, MAXTEXT, 0)==-1){
                printf("message send to A is failed");            
            }
            if(msgsnd(mqid_b, bufB, MAXTEXT, 0)==-1){
                printf("message send to B is failed");            
            }
            if(msgsnd(mqid_c, bufC, MAXTEXT, 0)==-1){
                printf("message send to C is failed");            
            }
        } // end of if
    }     /* end of whie */
}

int evalgame(char a, char b,char c)
{   
    if (((a == b )&&(b==c)&&(c==a))|| ((a !=b)&&(b!=c)&&(c!=a)))
        return 0; /* retry... */
    //W = papar, M = rock, V = scissors

    switch (a)
    {
    case 'W':
        switch (b)
        {
        case 'W'://a = W, b = W,
            if(c == 'M') return 4;  //c = M -> A,B win
            else if (c=='V') return 3; //c=V -> C win
            //c = W is defined at the top.
            break;
        case 'M'://a=W b=M
            if (c == 'M') return 1; //c =M A win
            else if (c == 'W') return 5; //c=W A,C win
            //c = V  is defined at the top
            break;
        case 'V': //a=W, b=M
            if (c == 'W') return 2; //c =M B win
            else if (c == 'V') return 6; //c=W B,C win
            //c = M is defined..
            break;
        }
        break;
    case 'M':
        switch (b)
        {
        case 'W':
            if(c == 'W') return 6;  //c = W b,c win
            else if (c=='M') return 2; //c=M b win
            //c = V is defined
            break;
        case 'M':
            if(c == 'W') return 3;  //c = M c win
            else if (c=='V') return 4; //c=V a b win
            break;                
        case 'V':
            if(c == 'M') return 5;  //c = M ac win
            else if (c=='V') return 1; //c = V a win
            break;
        }
        break;
    case 'V':
        switch (b)
        {
        case 'W':
            if(c == 'W') return 1;  //c = M a win
            else if (c=='V') return 5; //c=V ac win
            break;            
        case 'M':
            if(c == 'M') return 6;  //c = M bc win
            else if (c=='V') return 2; //c=V b win
            break;
        case 'V':
            if(c == 'W') return 4;  //c = M ab win
            else if (c=='M') return 3; //c=V c win
            break;
        }
        break;
    default :
        return 0;
    }
} /** end of evalgame */
